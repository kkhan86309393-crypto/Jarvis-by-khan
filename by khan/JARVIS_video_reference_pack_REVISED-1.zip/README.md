# J.A.R.V.I.S. Revised Portrait + Motion Reference Pack

## Main target portrait
`jarvis-target-portrait-transparent.png` is the user-supplied 1199x1312 RGBA portrait. Its alpha channel is preserved. The uploaded image already had transparent pixels around the subject, so no destructive background removal was needed. Use this as the target visual reference, subject to project-owner approval before replacing any existing project portrait.

## Motion references
`motion_reference_frames/` contains only the consistent close-up portion of the supplied video. The cutaway containing a man and the final wide-shot interval have been excluded.
`motion_contact_sheet.jpg` gives a quick overview.
`frame_manifest.json` maps each retained frame to its original timestamp.

## Important
Motion-reference frames are not transparent layers and are not the same portrait as the supplied target portrait. Do not paste full video frames over the portrait. Use them only to study blink timing and mouth/viseme movement. To make true blink/lip-sync assets, create properly aligned transparent eyelid and mouth/viseme layers for the target portrait. Preserve the target portrait's alpha.
Do not identify the person in the images. Do not modify the repository's canonical portrait without explicit approval.
