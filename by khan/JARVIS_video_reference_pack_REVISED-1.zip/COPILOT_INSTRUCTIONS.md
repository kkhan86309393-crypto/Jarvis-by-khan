# Copilot instructions — J.A.R.V.I.S. portrait blink + lip-sync

Repository: `/workspaces/Jarvis-by-khan`
Stack: HTML, CSS, JavaScript, Node.js, Three.js.

## Target portrait
Use `jarvis-target-portrait-transparent.png` as the requested target portrait reference. It is 1199x1312 RGBA and already contains transparency; preserve its alpha. Do not assume it should replace `public/jarvis-portrait.png`: first compare and report compatibility, and request approval before changing the canonical project portrait.

## Motion reference
Inspect `motion_contact_sheet.jpg`, `frame_manifest.json`, and `motion_reference_frames/`.
Only consistent close-up frames are included. Cutaway and final wide-shot intervals containing a male subject/shot change were removed from this pack. The video frames are motion references only, not transparent assets and not the same target portrait.

## Required process
1. Read-only audit first: worktree status, existing portrait checksum/dimensions, animation controller, speech lifecycle, markup, CSS, tests.
2. Analyze useful retained frames and map timestamps to eye states and mouth/viseme shapes.
3. Assess whether target portrait pose, crop, lighting, and facial proportions match the motion reference.
4. Do not use full video frames as overlays. Do not alter the canonical portrait until explicitly approved.
5. Design aligned transparent assets for blink (open/half/closed/reopen) and lip sync (rest, AI, E, O, U, FV, L, MBP and any needed visemes). Keep blink and lip-sync independent and composable.
6. If reliable aligned assets cannot be created from the available source, explain the limitation; do not fake them with colored CSS patches.
7. Report the asset plan and wait for approval before modifying code.
8. After approval, implement minimally, add/update tests, run `npm run check`, relevant tests, `git diff --check`, and verify portrait checksum.
9. No commit or push without explicit approval.

Deliver: timestamp/state map, portrait compatibility assessment, exact asset list, implementation plan, tests and browser validation steps.
